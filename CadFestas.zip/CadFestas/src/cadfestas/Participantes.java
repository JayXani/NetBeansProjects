
package cadfestas;

public class Participantes {
    private String nomeParticpante;

    public Participantes(String nomeParticpante) {
        this.nomeParticpante = nomeParticpante;
    }
    
}

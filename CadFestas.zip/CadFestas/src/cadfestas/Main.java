package cadfestas;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args){
        CrudFesta sendDados;
        Scanner teclado = new Scanner(System.in);
        String teste;
        String menu = "Bem vindo ! \n\nDigite o numero da opção que deseje: \n"
                + "1) Criar uma nova festa\n"
                + "2) Descobrir seu MATCH ! hehehe\n"
                + "3) Cadastrar novo participante";
        
        System.out.println(menu);  
        teste = teclado.next();
        switch(teste){
            case "1":
                
                break;
            case "2": 
                break;
            case "3":
                break;
        }
    }
}

package cadfestas;

import java.util.ArrayList;

public class Festas {
    private String nome;
    private String descricao;
    
    ArrayList<String> perguntas;
    ArrayList<String> respostas;
    ArrayList<Participantes> novoParticipante;

    public Festas(String nome, String descricao) {
        this.nome = nome;
        this.descricao = descricao;
    }

    public ArrayList<Participantes> getNovoParticipante() {
        return novoParticipante;
    }

    public void setNovoParticipante(ArrayList<Participantes> novoParticipante) {
        this.novoParticipante = novoParticipante;
    }

    public ArrayList<String> getPerguntas() {
        return perguntas;
    }

    public void setPerguntas(ArrayList<String> perguntas) {
        this.perguntas = perguntas;
    }

    public ArrayList<String> getRespostas() {
        return respostas;
    }

    public void setRespostas(ArrayList<String> respostas) {
        this.respostas = respostas;
    }
    
}

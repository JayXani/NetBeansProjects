
package cadfestas;

import java.util.ArrayList;

public class CrudFesta{
    ArrayList <Festas> novaFesta = new ArrayList();
    ArrayList <Participantes> novoParticipante = new ArrayList();
    Festas dadosFesta;
    
    public boolean verificadorDeparticipantes(){
        return novoParticipante.get(0) != null;
    }
    public void cadastrarFesta(){
        novaFesta.add(dadosFesta);
        
    }
    
    
}

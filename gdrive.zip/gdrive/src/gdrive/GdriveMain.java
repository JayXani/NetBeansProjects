package gdrive;

import java.util.Scanner;

public class GdriveMain {

    public static void main(String[] args) {
        Gdrive drive = new Gdrive();
        Pasta newPasta;
        String menu = "1) Criar Pasta\n2) Criar um arquivo\n 3) Criar uma subPasta";
        String escolha;
        boolean stop = true;
        Scanner teclado = new Scanner(System.in);
        System.out.println("Informe a opcao que deseja: \n\n");
        escolha = teclado.next();

        while (stop != false) {
            switch (escolha) {
                case "1":
                    System.out.println("Informe o nome da pasta que deseja: ");
                    String nomePasta = teclado.nextLine();
                    newPasta = new Pasta(nomePasta);
                    drive.adicionarPasta(newPasta);
                    System.out.println(drive.novaPasta.get(0).nomePasta);
                    break;
            }
        }

    }

}

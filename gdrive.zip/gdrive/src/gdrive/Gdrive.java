/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gdrive;

import java.util.ArrayList;

/**
 *
 * @author Fatec
 */
public class Gdrive{
    ArrayList<Pasta> novaPasta = new ArrayList();
    public void adicionarPasta(Pasta adicionarPasta){
        novaPasta.add(adicionarPasta);
    }
    public void adicionarSubPastas(String nomePasta){
       for(Pasta searchPasta : novaPasta){
           
       }
    }
    public void calcTamanhoPast(){
        
    }
    public void excluirPasta(){
    
    }
    
}

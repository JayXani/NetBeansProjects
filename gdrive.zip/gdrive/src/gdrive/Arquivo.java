/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gdrive;

/**
 *
 * @author Fatec
 */
public class Arquivo {
    String nomeArquivo;
    String tipoArquivo;
    double tamanhoArquivo;

    public Arquivo(String nomeArquivo, String tipoArquivo, double tamanhoArquivo) {
        this.nomeArquivo = nomeArquivo;
        this.tipoArquivo = tipoArquivo;
        this.tamanhoArquivo = tamanhoArquivo;
    }  
}
